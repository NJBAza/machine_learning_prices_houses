import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PACKAGE_ROOT = Path(os.path.abspath(os.path.dirname(__file__)))
sys.path.append(str(PACKAGE_ROOT.parent))

from prediction_model.config import config
from prediction_model.processing.data_handling import (
    load_dataset,
    load_pipeline,
)

classification_pipeline = load_pipeline(config.MODEL_NAME)


# For a unique case
def predictions(data_input):
    data = pd.DataFrame(data_input)
    FEATURES = list(data.columns)
    FEATURES.remove(config.TARGET)
    pred = classification_pipeline.predict(data[FEATURES])
    output = np.where(
        pred == 1,
        "250000-350000",
        np.where(
            pred == 2,
            "350000-450000",
            np.where(
                pred == 3,
                "450000-650000",
                np.where(pred == 4, "650000+", "0-250000"),
            ),
        ),
    )
    result = {"Predictions": output}
    return result


# # For a complete dataset-batch case
# def predictions():
#     test_data = load_dataset(config.TEST_FILE)
#     FEATURES = list(test_data.columns)
#     FEATURES.remove(config.TARGET)
#     pred = classification_pipeline.predict(test_data[FEATURES])
#     output = np.where(
#         pred == 1,
#         "250000-350000",
#         np.where(
#             pred == 2,
#             "350000-450000",
#             np.where(
#                 pred == 3,
#                 "450000-650000",
#                 np.where(pred == 4, "650000+", "0-250000"),
#             ),
#         ),
#     )
#     # result = {"Predictions": output}
#     return print(output)


# if __name__ == "__main__":
#     predictions()
